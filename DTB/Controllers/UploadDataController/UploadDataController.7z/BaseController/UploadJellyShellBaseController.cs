﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DTB.Data;
using DTB.Data.BatteryData;
using DTB.Controllers;
using DTB.Data.BatteryData.BaseModel;

public abstract class JellyShellBaseController<T> : ControllerBase where T : JellyShellBaseModel
{
    protected readonly IDbContextFactory<BatteryDbContext> _contextFactory;
    protected abstract DbSet<T> GetDbSet(BatteryDbContext context);
    protected JellyShellBaseController(IDbContextFactory<BatteryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    [HttpPost]
    public virtual async Task<ActionResult<ApiResponse<T>>> Post(T data)
    {
        try
        {
            if (data == null)
            {
                return BadRequest(ApiResponse<T>.Error(400, "Data is null"));
            }

            if (string.IsNullOrEmpty(data.JellyCode))
            {
                return BadRequest(ApiResponse<T>.Error(400, "JellyCode is required"));
            }

            // Create a new context from the factory
            await using var context = await _contextFactory.CreateDbContextAsync();
            var dbSet = GetDbSet(context);

            // Begin transaction
            await using var transaction = await context.Database.BeginTransactionAsync();
            try
            {
                // Check if main data exists
                var exists = await dbSet.AnyAsync(x => x.JellyCode == data.JellyCode);
                if (exists)
                {
                    return Conflict(ApiResponse<T>.Error(409, $"JellyCode {data.JellyCode} already exists"));
                }

                // Add main data
                data.updateTime = DateTime.Now;
                await dbSet.AddAsync(data);

                // Add related data to BatteryRelation table
                var batteryRelation = new BatteryRelation
                {
                    JellyCode = data.JellyCode,
                    ShellCode = data.ShellCode,
                    // If FilmCode is needed, get it from data
                    // FilmCode = data.FilmCode 
                };

                // Check for existing records in BatteryRelation
                var batteryRelationSet = context.Set<BatteryRelation>();

                var existingJelly = await batteryRelationSet
                    .FirstOrDefaultAsync(x => x.JellyCode == data.JellyCode);
                if (existingJelly != null)
                {
                    return Conflict(ApiResponse<T>.Error(409, $"JellyCode {data.JellyCode} already exists in BatteryRelation"));
                }

                var existingShell = await batteryRelationSet
                    .FirstOrDefaultAsync(x => x.ShellCode == data.ShellCode);
                if (existingShell != null)
                {
                    return Conflict(ApiResponse<T>.Error(409, $"ShellCode {data.ShellCode} already exists in BatteryRelation"));
                }

                await batteryRelationSet.AddAsync(batteryRelation);
                await context.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(ApiResponse<T>.Success(data, "Data saved successfully"));
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw; // Rethrow the exception for outer catch block
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, ApiResponse<T>.Error(500, $"Internal server error: {ex.Message}"));
        }
    }
}