﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DTB.Data;
using DTB.Data.BatteryData;
using DTB.Controllers;
using DTB.Data.BatteryData.BaseModel;

public abstract class ShellBaseController<T> : ControllerBase where T : ShellBaseModel
{
    protected readonly IDbContextFactory<BatteryDbContext> _contextFactory;
    protected abstract DbSet<T> GetDbSet(BatteryDbContext context);
    protected ShellBaseController(IDbContextFactory<BatteryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    [HttpPost]
    public virtual async Task<ActionResult<ApiResponse<T>>> Post(T data)
    {
        try
        {
            if (data == null)
            {
                return BadRequest(ApiResponse<T>.Error(400, "Data is null"));
            }

            if (string.IsNullOrEmpty(data.ShellCode))
            {
                return BadRequest(ApiResponse<T>.Error(400, "FilmCode is required"));
            }

            await using var context = await _contextFactory.CreateDbContextAsync();
            var dbSet = GetDbSet(context);

            var exists = await dbSet.AnyAsync(x => x.ShellCode == data.ShellCode);
            if (exists)
            {
                return Conflict(ApiResponse<T>.Error(409, $"ShellCode {data.ShellCode} already exists"));
            }

            data.updateTime = DateTime.Now;
            await dbSet.AddAsync(data);
            await context.SaveChangesAsync();

            return Ok(ApiResponse<T>.Success(data, "Data saved successfully"));
        }
        catch (Exception ex)
        {
            return StatusCode(500, ApiResponse<T>.Error(500, $"Internal server error: {ex.Message}"));
        }
    }


}