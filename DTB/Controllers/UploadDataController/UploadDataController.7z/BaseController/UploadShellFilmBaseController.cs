﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DTB.Data;
using DTB.Data.BatteryData;
using DTB.Controllers;
using DTB.Data.BatteryData.BaseModel;

public abstract class ShellFilmBaseController<T> : ControllerBase where T : ShellFilmBaseModel
{
    protected readonly IDbContextFactory<BatteryDbContext> _contextFactory;
    protected abstract DbSet<T> GetDbSet(BatteryDbContext context);
    protected ShellFilmBaseController(IDbContextFactory<BatteryDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    [HttpPost]
    public virtual async Task<ActionResult<ApiResponse<T>>> Post(T data)
    {
        try
        {
            if (data == null)
            {
                return BadRequest(ApiResponse<T>.Error(400, "Data is null"));
            }

            if (string.IsNullOrEmpty(data.ShellCode))
            {
                return BadRequest(ApiResponse<T>.Error(400, "ShellCode is required"));
            }

            if (string.IsNullOrEmpty(data.FilmCode))
            {
                return BadRequest(ApiResponse<T>.Error(400, "FilmCode is required"));
            }

            // Create a new context from the factory
            await using var context = await _contextFactory.CreateDbContextAsync();
            var dbSet = GetDbSet(context);

            // Start transaction
            await using var transaction = await context.Database.BeginTransactionAsync();
            try
            {
                // Check if FilmCode already exists
                var existingFilm = await dbSet.AnyAsync(x => x.FilmCode == data.FilmCode);
                if (existingFilm)
                {
                    return Conflict(ApiResponse<T>.Error(409, $"FilmCode {data.FilmCode} already exists"));
                }

                // Check if ShellCode already has a Film associated
                var existingShellFilm = await dbSet.FirstOrDefaultAsync(x => x.ShellCode == data.ShellCode);
                if (existingShellFilm != null)
                {
                    return Conflict(ApiResponse<T>.Error(409, $"ShellCode {data.ShellCode} already has an associated Film"));
                }

                // Add main data
                data.updateTime = DateTime.Now;
                await dbSet.AddAsync(data);

                // Check if ShellCode exists in BatteryRelation and update or insert accordingly
                var batteryRelationSet = context.Set<BatteryRelation>();
                var existingBatteryRelation = await batteryRelationSet
                    .FirstOrDefaultAsync(x => x.ShellCode == data.ShellCode);

                if (existingBatteryRelation != null)
                {
                    // Update existing record
                    existingBatteryRelation.FilmCode = data.FilmCode;
                    batteryRelationSet.Update(existingBatteryRelation);
                }
                else
                {
                    // Insert new record
                    var batteryRelation = new BatteryRelation
                    {
                        ShellCode = data.ShellCode,
                        FilmCode = data.FilmCode
                    };
                    await batteryRelationSet.AddAsync(batteryRelation);
                }

                await context.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(ApiResponse<T>.Success(data, "Data saved successfully"));
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                throw; // Re-throw exception for outer catch to handle
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, ApiResponse<T>.Error(500, $"Internal server error: {ex.Message}"));
        }
    }
}