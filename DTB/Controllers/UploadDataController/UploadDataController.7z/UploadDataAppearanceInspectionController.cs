﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class AppearanceInspectionController : FilmBaseController<AppearanceInspectionData>
{
    public AppearanceInspectionController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }
    protected override DbSet<AppearanceInspectionData> GetDbSet(BatteryDbContext context)
    {
        return context.AppearanceInspectionDatas;  // 返回具体的 DbSet
    }
}