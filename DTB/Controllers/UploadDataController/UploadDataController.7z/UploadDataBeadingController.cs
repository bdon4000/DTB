﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class BeadingController : ShellBaseController<BeadingData>
{
    public BeadingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<BeadingData> GetDbSet(BatteryDbContext context)
    {
        return context.BeadingDatas;  // 返回具体的 DbSet
    }
}