﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class BiInsertingDataController : JellyBaseController<BiInsertingData>
{
    public BiInsertingDataController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<BiInsertingData> GetDbSet(BatteryDbContext context)
    {
        return context.BiInsertingDatas;  // 返回具体的 DbSet
    }
}