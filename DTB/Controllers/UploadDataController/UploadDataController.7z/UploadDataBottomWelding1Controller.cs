﻿
using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class BottomWelding1Controller : ShellBaseController<BottomWelding1Data>
{
    public BottomWelding1Controller(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }
    protected override DbSet<BottomWelding1Data> GetDbSet(BatteryDbContext context)
    {
        return context.BottomWelding1Datas;  // 返回具体的 DbSet
    }
}