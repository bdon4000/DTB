﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class BottomWelding2Controller : ShellBaseController<BottomWelding2Data>
{
    public BottomWelding2Controller(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<BottomWelding2Data> GetDbSet(BatteryDbContext context)
    {
        return context.BottomWelding2Datas;  // 返回具体的 DbSet
    }
}