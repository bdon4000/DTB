﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class CapWeldingController : ShellBaseController<CapWeldingData>
{
    public CapWeldingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<CapWeldingData> GetDbSet(BatteryDbContext context)
    {
        return context.CapWeldingDatas;  // 返回具体的 DbSet
    }
}