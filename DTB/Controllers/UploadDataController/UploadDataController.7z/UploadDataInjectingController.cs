﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class InjectingController : ShellBaseController<InjectingData>
{
    public InjectingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<InjectingData> GetDbSet(BatteryDbContext context)
    {
        return context.InjectingDatas;  // 返回具体的 DbSet
    }
}