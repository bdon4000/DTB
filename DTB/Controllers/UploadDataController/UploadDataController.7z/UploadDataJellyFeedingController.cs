﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class JellyFeedingController : JellyBaseController<JellyFeedingData>
{
    public JellyFeedingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<JellyFeedingData> GetDbSet(BatteryDbContext context)
    {
        return context.JellyFeedingDatas;  // 返回具体的 DbSet
    }
}