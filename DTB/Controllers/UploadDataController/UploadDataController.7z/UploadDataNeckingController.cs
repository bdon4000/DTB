﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class NeckingController : ShellBaseController<NeckingData>
{
    public NeckingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<NeckingData> GetDbSet(BatteryDbContext context)
    {
        return context.NeckingDatas;  // 返回具体的 DbSet
    }
}