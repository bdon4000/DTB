﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class PlasticFilmingController : ShellBaseController<PlasticFilmingData>
{
    public PlasticFilmingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<PlasticFilmingData> GetDbSet(BatteryDbContext context)
    {
        return context.PlasticFilmingDatas;  // 返回具体的 DbSet
    }
}