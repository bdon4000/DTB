﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class PreChargeController : FilmBaseController<PreChargeData>
{
    public PreChargeController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }
    protected override DbSet<PreChargeData> GetDbSet(BatteryDbContext context)
    {
        return context.PreChargeDatas;  // 返回具体的 DbSet
    }
}