﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class ShellInsertingController : JellyShellBaseController<ShellInsertingData>
{
    public ShellInsertingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<ShellInsertingData> GetDbSet(BatteryDbContext context)
    {
        return context.ShellInsertingDatas;  // 返回具体的 DbSet
    }
}