﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class ShortCircuitTestController : ShellBaseController<ShortCircuitTestData>
{
    public ShortCircuitTestController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }
    protected override DbSet<ShortCircuitTestData> GetDbSet(BatteryDbContext context)
    {
        return context.ShortCircuitTestDatas;  // 返回具体的 DbSet
    }
}