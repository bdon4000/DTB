﻿using Microsoft.AspNetCore.Mvc;
using DTB.Data;
using DTB.Data.BatteryData;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
using DTB.Controllers;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/uploadData/[controller]")]
public class TiInsertingController : ShellBaseController<TiInsertingData>
{
    public TiInsertingController(IDbContextFactory<BatteryDbContext> contextFactory)
        : base(contextFactory)
    {
    }

    protected override DbSet<TiInsertingData> GetDbSet(BatteryDbContext context)
    {
        return context.TiInsertingDatas;  // 返回具体的 DbSet
    }
}